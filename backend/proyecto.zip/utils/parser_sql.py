import sqlparse
import re

def traducir_sql_a_kv(sql):
    sql = sql.strip()
    parsed = sqlparse.parse(sql)[0]
    tipo = parsed.get_type()
    tokens = [t.value for t in parsed.tokens if not t.is_whitespace]

    if tipo == "SELECT":
        sql = sql.strip(";").strip()

        # 1. SELECT con condición de campo distinto a ID
        match_filtro = re.match(
            r"SELECT\s+(.*?)\s+FROM\s+(\w+)\s+WHERE\s+(\w+)\s*(=|>|<|>=|<=)\s*['\"]?([\w\s]+)['\"]?",
            sql, re.IGNORECASE
        )
        if match_filtro:
            columnas = match_filtro.group(1).strip()
            tabla = match_filtro.group(2)
            campo = match_filtro.group(3).strip().lower()
            operador = match_filtro.group(4)
            valor = match_filtro.group(5).strip()

            if campo == "id":
                match_filtro = None  # Dejar que lo maneje match_id
            else:
                if valor.isdigit():
                    valor = int(valor)

                if columnas == "*":
                    columnas = None
                else:
                    columnas = [c.strip().lower() for c in columnas.split(",")]

                return ("GET_FILTER", tabla, {"campo": campo, "operador": operador, "valor": valor}, columnas)

        # 2. SELECT con WHERE id = ...
        match_id = re.match(
            r"SELECT\s+(.*?)\s+FROM\s+(\w+)\s+WHERE\s+id\s*=\s*['\"]?(\w+)['\"]?",
            sql, re.IGNORECASE
        )
        if match_id:
            columnas = match_id.group(1).strip()
            tabla = match_id.group(2)
            id_val = match_id.group(3)

            if columnas == "*":
                columnas = None
            else:
                columnas = [col.strip().lower() for col in columnas.split(",")]

            return ("GET", tabla, id_val, columnas)

        # 3. SELECT sin WHERE
        match_all = re.match(
            r"SELECT\s+(.*?)\s+FROM\s+(\w+)",
            sql, re.IGNORECASE
        )
        if match_all:
            columnas = match_all.group(1).strip()
            tabla = match_all.group(2)

            if columnas == "*":
                columnas = None
            else:
                columnas = [col.strip().lower() for col in columnas.split(",")]

            return ("GET_ALL", tabla, columnas)

        raise ValueError("No se pudo analizar la sentencia SELECT.")



    elif tipo == "INSERT":
        tabla = tokens[2]
        for t in tokens:
            if "VALUES" in t.upper():
                valores = t[t.find("(")+1 : t.find(")")].split(",")
                id_val = valores[0].strip()
                payload = {
                    "nombre": valores[1].strip().strip("'"),
                    "edad": int(valores[2]),
                    "ciudad": valores[3].strip().strip("'")
                }
                return ("SET", tabla, id_val, payload)

    elif tipo == "DELETE":
        tabla = tokens[3]
        for t in tokens:
            if "WHERE" in t.upper():
                parte_where = t.upper().split("WHERE")[1]
                id_val = parte_where.split("=")[1].replace(";", "").strip().strip("'")
                return ("DEL", tabla, id_val)

    elif tipo == "UPDATE": #no funciona con sqlparse, se usa regex
        tabla = tokens[1]
        
        match = re.search(r"SET\s+(.*?)\s+WHERE\s+id\s*=\s*['\"]?(\w+)['\"]?", sql, re.IGNORECASE)
        if not match:
            raise ValueError("No se encontraron campos válidos o ID en la cláusula UPDATE.")
        
        set_clause = match.group(1)
        id_val = match.group(2)
        
        campos = set_clause.split(",")
        payload = {}
        
        for campo in campos:
            if "=" not in campo:
                continue
            k, v = campo.strip().split("=")
            k = k.strip().lower()
            v = v.strip().strip("'").strip('"')
            payload[k] = int(v) if v.isdigit() else v

        if not payload:
            raise ValueError("No se encontraron campos válidos en la cláusula SET.")

        return ("UPDATE", tabla, id_val, payload)

    raise ValueError("Consulta no reconocida")
