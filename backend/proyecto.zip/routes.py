from flask import Blueprint, request, jsonify
from controllers.consulta_controller import procesar_consulta

consulta_routes = Blueprint('consulta_routes', __name__)

@consulta_routes.route('/consulta', methods=['POST'])
def consulta():
    data = request.get_json()
    sql = data.get('sql')
    resultado = procesar_consulta(sql)
    return jsonify(resultado)
