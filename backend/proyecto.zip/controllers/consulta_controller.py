from services.traductor_service import traducir_y_ejecutar

def procesar_consulta(sql):
    try:
        resultado = traducir_y_ejecutar(sql)
        return {"resultado": resultado}
    except Exception as e:
        return {"error": str(e)}
