import firebase_admin
from firebase_admin import credentials, db

cred = credentials.Certificate('credenciales-firebase.json')
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://middleware-kv-default-rtdb.europe-west1.firebasedatabase.app/'
})

def set_usuario(id, data):
    if not data:
        raise ValueError("El diccionario de actualización está vacío.")
    ref = db.reference(f'usuarios/{id}')
    ref.update(data) #ref.set borra todo el nodo, ref.update solo actualiza los campos especificados

def get_usuario(id):
    ref = db.reference(f'usuarios/{id}')
    return ref.get()

def get_todos(tabla):
    ref = db.reference(tabla)
    return ref.get()

def delete_usuario(id):
    ref = db.reference(f'usuarios/{id}')
    ref.delete()
