from utils.parser_sql import traducir_sql_a_kv
from database.firebase_client import get_todos, set_usuario, get_usuario, delete_usuario

def traducir_y_ejecutar(sql):
    result = traducir_sql_a_kv(sql)
    op = result[0]
    if op == "GET":
        data = get_usuario(result[2])
        if result[3]:  # columnas específicas
            data = {k: v for k, v in data.items() if k in result[3]}
        return data
    elif op == "GET_ALL":
        todos = get_todos(result[1])
        if result[2]:  # columnas específicas
            for k in todos:
                todos[k] = {campo: valor for campo, valor in todos[k].items() if campo in result[2]}
        return todos
    elif op == "GET_FILTER":
        registros = get_todos(result[1])
        filtro = result[2]
        columnas = result[3]

        campo = filtro["campo"]
        operador = filtro["operador"]
        valor = filtro["valor"]

        def cumple_condicion(registro):
            v = registro.get(campo)
            if v is None:
                return False
            try:
                if operador == "=": return v == valor
                if operador == ">": return v > valor
                if operador == "<": return v < valor
                if operador == ">=": return v >= valor
                if operador == "<=": return v <= valor
            except TypeError:
                return False
            return False

        filtrados = {k: v for k, v in registros.items() if cumple_condicion(v)}

        if columnas:
            for k in filtrados:
                filtrados[k] = {c: v for c, v in filtrados[k].items() if c in columnas}

        return filtrados

    elif op == "SET":
        set_usuario(result[2], result[3])
        return "Usuario insertado"
    elif op == "DEL":
        delete_usuario(result[2])
        return "Usuario eliminado"
    elif op == "UPDATE":
        set_usuario(result[2], result[3])
        return "Usuario actualizado"

